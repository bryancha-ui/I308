<?php

$con=mysqli_connect("db.soic.indiana.edu","i308s21_team34","my+sql=i308s21_team34", "i308s21_team34");
// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
	
$sanstate = mysqli_real_escape_string($con, $_POST['form_state']);



$sql2 = "SELECT CONCAT(e.nameFirst, '', e.nameLast) AS name, e.position AS position, v.state AS state, vp.appeal AS appealed, COUNT(v.lp_num) AS number, vo.fine_amount AS amount
FROM employees AS e
JOIN violation_payments AS vp ON vp.empid = e.empid
JOIN vehicle AS v ON v.lp_num = vp.lp_num
JOIN violations AS vo ON vo.lp_num = vp.lp_num
WHERE  v.state = '".$sanstate."' AND e.position = 'supervisor';";
$result = mysqli_query($con, $sql2);
$num_rows = mysqli_num_rows($result);

if ($result->num_rows > 0) {
	Echo "<table border=1>";
Echo "<tr><th>Results<th><tr>";

while($row = $result->fetch_assoc()) {
	Echo "<tr><td>" .$row["name"]."</td><td>".$row["position"]."</td><td>".$row["state"]."</td><td>".$row["appealed"]."</td><td>".$row["number"]."</td><td>".$row["amount"]."</td></tr>";
		}
echo "</table>";
} else {
  echo "0 results";
}
Echo "$num_rows Rows\n";  
mysqli_close($con);
?>

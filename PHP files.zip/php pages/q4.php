<?php

$con=mysqli_connect("db.soic.indiana.edu","i308s21_team34","my+sql=i308s21_team34", "i308s21_team34");
// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
$result = mysqli_query($conn,"SELECT distinct permit FROM permits");	
$sanpID = mysqli_real_escape_string($con, $_POST['form_pID']);


$sql2 = "SELECT v.make AS make, CONCAT(u.fname, ' ', u.lname) AS name 
FROM vehicle AS v 
JOIN parking_user AS u ON v.user_id = u.user_id 
JOIN receipt AS r ON v.lp_num = r.lp_num 
WHERE r.permit_id = '".$sanpID."'";
$result2 = mysqli_query($con, $sql2);
$num_rows = mysqli_num_rows($result2);

if ($result2->num_rows > 0) {
	Echo "<table border=1>";
Echo "<tr><th>Results<th><tr>";

while($row = $result2->fetch_assoc()) {
	Echo "<tr><td>" .$row["make"]."</td><td>".$row["name"]."</td></tr>";
		}
echo "</table>";
} else {
  echo "0 results";
}
Echo "$num_rows Rows\n";  
mysqli_close($con);
?>

<?php

$con=mysqli_connect("db.soic.indiana.edu","i308s21_team34","my+sql=i308s21_team34", "i308s21_team34");
// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
$result = mysqli_query($conn,"SELECT distinct permit FROM permits");
$santype = mysqli_real_escape_string($con, $_POST['form_type']);


$sql2 = "SELECT COUNT(l.lot_id) AS Unpermitted_Locations
FROM locations AS l
JOIN permits AS p ON p.permit_id=l.permit_id
WHERE p.permit_id NOT IN (
SELECT l.lot_id 
FROM locations AS l
JOIN permits AS p ON p.permit_id=l.permit_id
WHERE p.type = '".$santype."');";
$result2 = mysqli_query($con, $sql2);
$num_rows = mysqli_num_rows($result2);

if ($result2->num_rows > 0) {
	Echo "<table>";
Echo "<tr><th>Results<th><tr>";

while($row = $result2->fetch_assoc()) {
	Echo "<tr><td>" .$row["Unpermitted_Locations"]."</td></tr>";
		}
echo "</table>";
} else {
  echo "0 results";
}
Echo "$num_rows Rows\n";  
mysqli_close($con);
?>

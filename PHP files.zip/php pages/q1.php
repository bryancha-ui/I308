<?php

$con=mysqli_connect("db.soic.indiana.edu","i308s21_team34","my+sql=i308s21_team34", "i308s21_team34");
// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
	
$sanmonth = mysqli_real_escape_string($con, $_POST['form_month']);

$sql2 = "SELECT CONCAT(u.fname, ' ', u.lname) AS name , up.phone AS phone, vo.date AS date
FROM parking_user AS u
JOIN parking_users_phone AS up ON up.user_id = u.user_id
JOIN vehicle AS v ON v.user_id = u.user_id
JOIN violations AS vo ON vo.lp_num = v.lp_num
WHERE (MONTH(vo.date) = '".$sanmonth."' )
ORDER BY name;";
$result2 = mysqli_query($con, $sql2);
$num_rows = mysqli_num_rows($result2);

if ($result2->num_rows > 0) {
	Echo "<table border=1>";
Echo "<tr><th>Results<th><tr>";

while($row = $result2->fetch_assoc()) {
	Echo "<tr><td>" .$row["name"]."</td><td>".$row["phone"]."</td>
			<td>" .$row["date"]."</td></tr>";
		}
echo "</table>";
} else {
  echo "0 results";
}
Echo "$num_rows Rows\n";  
mysqli_close($con);
?>

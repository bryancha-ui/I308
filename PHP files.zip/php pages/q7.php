<?php

$con=mysqli_connect("db.soic.indiana.edu","i308s21_team34","my+sql=i308s21_team34", "i308s21_team34");
// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
	
$sanfunct = mysqli_real_escape_string($con, $_POST['form_funct']);
$sanlocation = mysqli_real_escape_string($con, $_POST['form_location']);



$sql6 = "SELECT $sanfunct(vo.violation_num) AS number_of_tickets, vo.date AS date, l.lot_id AS lot 
FROM violations AS vo
JOIN locations AS l ON l.lot_id = vo.lot_id
WHERE l.lot_id =$sanlocation";


$result6 = $con->query($sql6);

if ($result6->num_rows > 0) {
    echo "<table border=1><tr><th>Number of Tickets</th><th>Date </th><th>Lot</th></tr>";
    // output data of each row
    while($row = $result6->fetch_assoc()) {
    echo "<tr><td>".$row["number_of_tickets"]."</td>
		<td>".$row["date"]." </td>
		<td>".$row["lot"]." </td>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
// Close Connection

?>

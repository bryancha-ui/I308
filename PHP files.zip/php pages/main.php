<!DOCTYPE html>
<html>
<body>
<h1> Query 1 </h1>
<h2>Pick a month and we will tell you all of the full names and phone numbers of parking users who got a violation that month.</h2>	
<form action="q1.php" method="post">
Month: <select name="form_month" required>
<option value="01">January</option>
<option value="02">February</option>
<option value="03">March</option>
<option value="04">April</option>
<option value="05">May</option>
<option value="06">June</option>
<option value="07">July</option>
<option value="08">August</option>
<option value="09">September</option>
<option value="10">October</option>
<option value="11">November</option>
<option value="12">December</option>
</select> <br>
	</br>
 <button type "submit" value = "Submit">Submit</button>

</form>

<h1> 2 </h1>
<h2>Insert a year either 2020 or 2021 and we will find the number of parking users who bought a permit in it</h2>
<form action="q2.php" method="post">
	Year: <input type="number" name="form_year" min="2020" max="2021" required><br>

 <button type "submit" value = "Submit">Submit</button>

</form>


<h1> 3 </h1>
<h2>Select a permit type and we will find the number of locations that a parking user cannot park at.</h2>
<form action="q3.php" method="post">
Permit Type: <select name="form_type" required>
<?php

$conn=mysqli_connect("db.soic.indiana.edu","i308s21_team34","my+sql=i308s21_team34", "i308s21_team34");
// Check connection
if (!$conn){
	die("Failed to connect to MySQL: " . mysqli_connect_error()); 
}
$result = mysqli_query($conn,"SELECT distinct type FROM permits");
            while ($row = mysqli_fetch_assoc($result)){
                unset($id,$name);
                $id = $row['permit_id'];
                $name=$row['type'];
                echo '<option value="'.$id.'">'.$name.'</option>';
            }

?>
		</select> 
	</br>
	 <button type "submit" value = "Submit">Submit</button>
</form>

<h1> 4 </h1>
<h2>Select the permitID and we will find the car make and name of the parking user who owns that permit</h2>
<form action="q4.php" method="post">
Permit ID: <select name="form_pID" required>
<?php

$conn=mysqli_connect("db.soic.indiana.edu","i308s21_team34","my+sql=i308s21_team34", "i308s21_team34");
// Check connection
if (!$conn){
	die("Failed to connect to MySQL: " . mysqli_connect_error()); 
}
$result = mysqli_query($conn,"SELECT distinct permit_id from permits");
            while ($row = mysqli_fetch_assoc($result)){
                unset($id, $name);
                $id= $row['permit_id'];
				$name=$row['permit_id'];
                echo '<option value="'.$id.'">'.$name.'</option>';
            }

?>
		</select> 
	</br>

 <button type "submit" value = "Submit">Submit</button>

</form>


<h1> 5 </h1>
<h2>Find the name of the employee who is the supervisor of every violation for the number of vehicles from Ohio and if it has been appealed, and provide the fine amount</h2>
<form action="q5.php" method="post">
	
State: <select name="form_state">
<?php

$conn=mysqli_connect("db.soic.indiana.edu","i308s21_team34","my+sql=i308s21_team34", "i308s21_team34");
// Check connection
if (!$conn){
	die("Failed to connect to MySQL: " . mysqli_connect_error()); 
}
$result = mysqli_query($conn,"SELECT distinct state FROM vehicle");
            while ($row = mysqli_fetch_assoc($result)){
                unset($id,$name);
                $id= $row['state'];
                $name=$row['state'];
                echo '<option value="'.$id.'">'.$name.'</option>';
            }

?>
		</select> 
	</br>

 <button type "submit" value = "Submit">Submit</button>

</form>

<h1> 6 </h1>
<h2>Allow the user to pick the function MIN, MAX, or AVG for the total number of tickets given for violations for all of a particular location on a particular date</h2>
<form action="q7.php" method="post">

Function: <select name="form_funct" required>
<option value="MIN">Minimum</option>
<option value="MAX">Maximum</option>
<option value="AVG">Average</option>
</select> <br>
	</br>
	
Location: <select name="form_location" >
<?php

$conn=mysqli_connect("db.soic.indiana.edu","i308s21_team34","my+sql=i308s21_team34", "i308s21_team34");
// Check connection
if (!$conn){
	die("Failed to connect to MySQL: " . mysqli_connect_error()); 
}
$result4 = mysqli_query($conn,"SELECT distinct lot_id, address from locations");
           while ($row = mysqli_fetch_assoc($result4)){
                unset($id,$name);
                $id= $row['lot_id'];
                $name=$row['address'];
                echo '<option value="'.$id.'">'.$name.'</option>';
            }

?>
		</select> 
	</br>
  <button type "submit" value = "Submit">submit</button>
</form>

</body>
</html>



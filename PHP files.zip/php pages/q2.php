<?php

$con=mysqli_connect("db.soic.indiana.edu","i308s21_team34","my+sql=i308s21_team34", "i308s21_team34");
// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
	
$sanyear = mysqli_real_escape_string($con, $_POST['form_year']);


$sql2 = "SELECT COUNT(p.user_id) AS Number, YEAR(r.pdate) AS Year
FROM parking_user AS p
JOIN vehicle AS v ON v.user_id=p.user_id
JOIN receipt AS r ON r.lp_num=v.lp_num
WHERE YEAR(r.pdate)= '".$sanyear."';";
$result2 = mysqli_query($con, $sql2);
$num_rows = mysqli_num_rows($result2);

if ($result2->num_rows > 0) {
	Echo "<table border=1>";
Echo "<tr><th>Results<th><tr>";

while($row = $result2->fetch_assoc()) {
	Echo "<tr><td>" .$row["Number"]."</td><td>".$row["Year"]."</td></tr>";
		}
echo "</table>";
} else {
  echo "0 results";
}
Echo "$num_rows Rows\n";  
mysqli_close($con);
?>
